<?php
// Call it now
$tinymce_button = new miss_add_mce_button(
    'miss_mce_plugin_shortcode_clear',
    'miss_clear',
    false
);
?>
