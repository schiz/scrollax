animo.js
========

A powerful little tool for managing CSS animations. Stack animations, create cross-browser blurring, set callbacks on animation completion, make magic.

Full article and demos - http://labs.bigroomstudios.com/libraries/animo-js

##License
All code is open source and licensed under MIT. Check the individual licenses for more information.

###Change log
####1.0.1
* Fixed callback firing after first animation when stacking animations

####1.0.0
* Initial release
